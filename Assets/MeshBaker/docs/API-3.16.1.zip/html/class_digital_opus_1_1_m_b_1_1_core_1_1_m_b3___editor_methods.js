var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods =
[
    [ "AddTextureFormat", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a96c5c0cd1795f849a133ecf87d075f82", null ],
    [ "CheckBuildSettings", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#ad79edf490da11914a2a82b310a6be27b", null ],
    [ "CheckPrefabTypes", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#affa0a832252b4042ae8eae4e432cd59e", null ],
    [ "Clear", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a03e116fc9ec65a8a006fa9c52a7a7aa4", null ],
    [ "CommitChangesToAssets", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#af913ea880e4906dd8d06f5e4f1f5ae31", null ],
    [ "Destroy", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a56450e6ef13bf52f2c6e1b73ad439b4e", null ],
    [ "GetPlatformString", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a811b5e88eb8e885dd368b47c95388f9f", null ],
    [ "IsCompressed", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#ae1714661e34d77dcab3a0a8f9c312a40", null ],
    [ "IsNormalMap", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a8166511938a8f6d8e95df37012e2b1f4", null ],
    [ "SaveAtlasToAssetDatabase", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#ac46293282a74a7eecfa2298cb2212dd3", null ],
    [ "SetMaterialTextureProperty", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a9419cda51a0f656db60be89f4caebb3d", null ],
    [ "SetNormalMap", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a0d0b76d9450dbd34a2b601afe61e74ab", null ],
    [ "SetReadFlags", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#acca042b2e52ee207e4ee5c5ed66ec3bb", null ],
    [ "SetReadWriteFlag", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#adf72a14d6a3580ec07f386a99310055f", null ],
    [ "SetTextureSize", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#aa6819bc1771a00d896dd34173b214b67", null ],
    [ "ValidateSkinnedMeshes", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html#a8f8021d75e9025a6ab5c9349a6ba8e2d", null ]
];