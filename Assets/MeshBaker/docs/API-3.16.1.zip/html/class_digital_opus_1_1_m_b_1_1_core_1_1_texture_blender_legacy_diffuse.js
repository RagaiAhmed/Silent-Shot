var class_digital_opus_1_1_m_b_1_1_core_1_1_texture_blender_legacy_diffuse =
[
    [ "DoesShaderNameMatch", "class_digital_opus_1_1_m_b_1_1_core_1_1_texture_blender_legacy_diffuse.html#a106c2da1532abaf78e6e7e5991fd460b", null ],
    [ "GetColorIfNoTexture", "class_digital_opus_1_1_m_b_1_1_core_1_1_texture_blender_legacy_diffuse.html#ad1581c35ed8112129a9765418e2b239c", null ],
    [ "NonTexturePropertiesAreEqual", "class_digital_opus_1_1_m_b_1_1_core_1_1_texture_blender_legacy_diffuse.html#adaa1204f466de9d33337ea9f6a6aaaec", null ],
    [ "OnBeforeTintTexture", "class_digital_opus_1_1_m_b_1_1_core_1_1_texture_blender_legacy_diffuse.html#aae0c7a56bb1ce8c2c1f5df11a0ee9197", null ],
    [ "OnBlendTexturePixel", "class_digital_opus_1_1_m_b_1_1_core_1_1_texture_blender_legacy_diffuse.html#a3984c3cc3ed6a772bd2c4eedd481b862", null ],
    [ "SetNonTexturePropertyValuesOnResultMaterial", "class_digital_opus_1_1_m_b_1_1_core_1_1_texture_blender_legacy_diffuse.html#a0ed87a5a70b9edcac2012903d3391e7f", null ]
];