var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set =
[
    [ "MB_TexSet", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a8f3908920a4a9895e01f80b4c5896841", null ],
    [ "AllTexturesAreSameForMerge", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a9732eb4d18b12cb475b1dbf28554d5b5", null ],
    [ "CalcInitialFullSamplingRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#ae8d6a3c5626d6ef619ece14eaf7a4095", null ],
    [ "CalcMatAndUVSamplingRectsIfAllMatTilingSame", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#aa8b78b098f5cec97db91880f9b98c36e", null ],
    [ "IsEqual", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a2c4c28adebef90aaa3b782ae68915ddd", null ],
    [ "allTexturesUseSameMatTiling", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a58f48ec608c677eba0a24259061de8bf", null ],
    [ "gos", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a5af227d649e9ba0ad909f1984fce81cd", null ],
    [ "idealHeight", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a1a4abff71c11fb8c612a535bd99b25e8", null ],
    [ "idealWidth", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#ac72157f102d3c888a9c55b1f1ef60849", null ],
    [ "mats", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#abb052581e9f3f8f9fdc561fbc4f11fff", null ],
    [ "obUVoffset", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#abaecac762f485c80029ff31a550c306f", null ],
    [ "obUVscale", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a4a1090d0163b23227e72bfe8cc861690", null ],
    [ "ts", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a3d9c6ce207f448317d7dd50bf109480d", null ],
    [ "obUVrect", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#ab2c1fb79fd0e443d7c154695d07da220", null ]
];