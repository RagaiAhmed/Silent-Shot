var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture =
[
    [ "MeshBakerMaterialTexture", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture.html#ac0d4c5da8a95af60b51e7966713116b8", null ],
    [ "MeshBakerMaterialTexture", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture.html#abd76f7a856675be194beadf672ad3ba7", null ],
    [ "MeshBakerMaterialTexture", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture.html#afc63967089478919b3ed090936381890", null ],
    [ "encapsulatingSamplingRect", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture.html#a9646935f4f7962db1e0a2250ebdea75b", null ],
    [ "matTilingRect", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture.html#a87d4b6bbe264e384ec5269d41543a05b", null ],
    [ "t", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture.html#ad907a2b730cd06b0edbc764bb1ea6c56", null ],
    [ "texelDensity", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_mesh_baker_material_texture.html#a8a8264178c3be72078ef352e34baa0d7", null ]
];