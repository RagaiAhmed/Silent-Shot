var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place =
[
    [ "BakeMeshesInPlace", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place.html#a900ae15a9b2aa16ab642a6280c09f3ef", null ],
    [ "BakeOneMesh", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place.html#aa43fcd5b85a1807c17299f4f81767f0f", null ]
];